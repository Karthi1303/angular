class BasicPhone extends Mobile {
   public mobileType: string;

   constructor(mobileId: number,mobileName: string,mobileCost: number, mobileType: string) {
       super(mobileId,mobileName,mobileCost);
       this.mobileType = mobileType;
   }
}