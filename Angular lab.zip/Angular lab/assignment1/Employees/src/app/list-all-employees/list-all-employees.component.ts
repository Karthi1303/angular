import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {
  employees: any[];
  employeeService: EmployeeService;
ngOnInit(){

}
show(){
  this.employees = this.employeeService.getEmployees();
}
  deleteEmployee(index: number) {
    this.employees.splice(index, 1);
  }
}
