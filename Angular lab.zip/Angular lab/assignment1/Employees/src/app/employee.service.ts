import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees: any[];
  
  listObject: ListAllEmployeesComponent;
  ID: number;
   NAME: string;
    EMAIL: string;
     PHONE: number
  constructor(private http: HttpClient, employeeService: EmployeeService, private router: Router) {
    this.getEmployee().subscribe(
      employee => {
        this.employees = employee;
      }
    );
   }
getEmployees(){
  this.employees.push({ id: this.ID, name: this.NAME, email: this.EMAIL, phone: this.PHONE});
  return this.employees;
}
  getEmployee(): Observable<any[]> {
   return this.http.get<any[]>('./assets/employees.json');
  }
  ngOnInit() {
  }
  updateEmployee(Id: number, Name: string, Email: string, Phone: number){
    this.ID=Id;
    this.NAME=Name;
    this.EMAIL=Email;
    this.PHONE=Phone;
    this.listObject.show();
    this.router.navigate(['/emplist']);
  }
}
