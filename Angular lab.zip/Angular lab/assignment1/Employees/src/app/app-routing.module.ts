import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';



const routes: Routes = [
  { path: 'emplist', component: ListAllEmployeesComponent },
  { path: 'addemp', component: AddEmployeeComponent },
  {
    path: '',
    redirectTo: 'emplist',
    pathMatch: 'full',
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
