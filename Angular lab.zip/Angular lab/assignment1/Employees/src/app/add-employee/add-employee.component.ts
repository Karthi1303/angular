import { Component, OnInit, Output } from '@angular/core';
import { EmployeeService } from '../employee.service';



@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
@Output()({

}
)
export class AddEmployeeComponent implements OnInit{
  ngOnInit(){
  }
  constructor(private employeeService: EmployeeService ) {
  }

  addEmployee(Id: number, Name: string, Email: string, Phone: number) {
   this.employeeService.updateEmployee(Id,Name,Email,Phone);
      }
}
