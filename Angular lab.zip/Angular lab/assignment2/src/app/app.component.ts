import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
OnSubmit(id: number, name: string, salary: number, dept: string) {
  alert(id + ' ' + name + ' ' + salary + ' ' + dept);
}
}
