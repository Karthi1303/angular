import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
uname = '';
uid = '';
usalary = '';
udept = '';
updateObject: any;
message = '';
   employees = [
    {empId: 1001, empName: 'Rahul', empSal: 9000, empDep: 'Java'},
    {empId: 1002, empName: 'Sachin', empSal: 19000, empDep: 'OraApps'},
    {empId: 1003, empName: 'Vikash', empSal: 29000, empDep: 'BI'},
    ];

  constructor() {}
addEmployee(id: number, name: string, salary: number, dept: string) {
this.employees.push({empId: id,  empName: name, empSal: salary, empDep: dept});
this.message = 'DATA INSERTED';
}
delEmployee(index: number) {
  this.employees.splice(index, 1);
  this.message = 'DATA Deleted';
}
update(emp: any) {
this.uid = emp.empId;
this.uname = emp.empName;
this.usalary = emp.empSal;
this.udept = emp.empDep;
this.updateObject = emp;

}
updateEmployee(Uid: number, Uname: string, Usalary: number, Udept: string) {
  this.updateObject.empId = Uid;
  this.updateObject.empName = Uname;
  this.updateObject.empSal = Usalary;
  this.updateObject.empDep = Udept;
  this.message = 'DATA Updated';
}
  ngOnInit() {
  }

}
