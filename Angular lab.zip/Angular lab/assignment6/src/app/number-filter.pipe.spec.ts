import { NumberFilterPipe } from './number-filter.pipe';

describe('NumberFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new NumberFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
