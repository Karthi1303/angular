import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'stringFilter'
})
export class StringFilterPipe implements PipeTransform {

  transform(toBeFilteredData: any, ...filter: any[]): any {
    return toBeFilteredData.filter((value) => {
        if(value.title.toUpperCase().indexOf(filter[0].toUpperCase()) !== -1 && value.author.toUpperCase().indexOf(filter[1].toUpperCase()) !== -1) return true;
        else return false;      
    })
 }

}
