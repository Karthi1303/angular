import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  booklist: any[];
  bindedId  = "";
  bindedTitle: string = "";
  bindedAuthor: string = "";
  bindedYear = "";
  constructor(private httpService: HttpClient) {}
  ngOnInit() { 
    this.httpService.get('./assets/booklist.json').subscribe(
      data=>{this.booklist = data as any[]}
  );
  }

}
