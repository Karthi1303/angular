import { StringFilterPipe } from './string-filter.pipe';

describe('StringFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new StringFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
