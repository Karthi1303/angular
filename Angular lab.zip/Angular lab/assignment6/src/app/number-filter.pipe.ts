import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'numberFilter'
})
export class NumberFilterPipe implements PipeTransform {

  transform(toBeFilteredData: any, ...filter: any[]): any {
  
    return toBeFilteredData.filter((value) => {
      if((value.id == filter[0] || filter[0] == "") && (value.year == filter[1] || filter[1] == "")) {
        return true;
      } else return false;
    });
  }

}
