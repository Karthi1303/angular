import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  employee: any[];

  constructor(private httpService: HttpClient) {}
  ngOnInit() { 
    this.httpService.get('./assets/employees.json').subscribe(
      data=>{this.employee = data as any[]}
  );
  }

}
